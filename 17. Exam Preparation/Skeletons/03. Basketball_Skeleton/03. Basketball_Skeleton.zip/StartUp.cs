﻿using System;
using System.Collections.Generic;

namespace Basketball
{
    public class StartUp
    {
        static void Main()
        {
        }
    }
}
